#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_STACK_SIZE 50

typedef int element;
typedef struct Stacktype {
    element* data;
    int capacity;
    int top;
} Stacktype;

int init(Stacktype* sptr, int nos) {
    sptr->data = (element*)malloc(sizeof(element) * nos);
    if (sptr->data == NULL) {
        fprintf(stderr, "Memory allocation failed\n");
        return -1;
    }
    sptr->top = -1;
    sptr->capacity = nos;
    return 0;
}

int is_full(Stacktype* sptr) {
    if (sptr->top == sptr->capacity - 1) {
        sptr->capacity *= 2;
        sptr->data = (element*)realloc(sptr->data, sptr->capacity * sizeof(element));
        printf("Capacity has extended\n");
    }
    return 0;
}

int is_empty(Stacktype* sptr) {
    return (sptr->top == -1);
}

void push(Stacktype* sptr, element item) {
    if (is_full(sptr)) {
        fprintf(stderr, "Stack is FULL\n");
        return;
    }
    else {
        sptr->top++;
        sptr->data[sptr->top] = item;
    }
}

element peek(Stacktype* sptr) {
    if (is_empty(sptr)) {
        fprintf(stderr, "stack is empty\n");
        return -1;
    }
    return sptr->data[sptr->top];
}

void print_stack(Stacktype* sptr) {
    if (is_empty(sptr)) {
        fprintf(stderr, "Stack is empty\n\n");
        return;
    }
    printf("Stack contents: ");
    for (int i = sptr->top; i >= 0; i--) {
        printf("%d ", sptr->data[i]);
    }
    printf("\n\n");
}

element pop(Stacktype* sptr) {
    if (is_empty(sptr)) {
        fprintf(stderr, "Stack is empty\n\n");
        return -1;
    }
    else {
        return sptr->data[sptr->top--];
    }
}

void stack_print(Stacktype* sptr) {
    printf("Stack contents: ");
    for (int i = sptr->top; i >= 0; i--) {
        printf("%d ", sptr->data[i]);
    }
    printf("\n");
}

int eval(char* expr) {
    Stacktype s;
    int len = strlen(expr);
    int op1, op2;

    init(&s, len);

    for (int i = 0; i < len; i++) {
        int value;
        int ch = expr[i];

        if (ch == '+' || ch == '-' || ch == '/' || ch == '*') {
            op1 = pop(&s);
            op2 = pop(&s);
            switch (ch) {
            case '+':
                push(&s, op2 + op1);
                break;
            case '-':
                push(&s, op2 - op1);
                break;
            case '/':
                push(&s, op2 / op1);
                break;
            case '*':
                push(&s, op2 * op1);
                break;
            }
        }
        else if (ch >= '0' && ch <= '9') {
            value = ch - '0';
            push(&s, value);
        }
        else {
            continue;
        }
        //stack_print(&s);
    }
    return (pop(&s));
}

char* ScanExpression() {
    static char expression[MAX_STACK_SIZE];
    printf("Enter the postfix expression: ");
    fgets(expression, MAX_STACK_SIZE, stdin);
    return expression;
}

int prec(char op) {
    switch (op) {
    case '(': case ')': return 0;
    case '+': case '-': return 1;
    case '*': case '/': return 2;
    }
    return -1;
}

char* infix_to_postfix(char* infix) {
    static char Exp[MAX_STACK_SIZE];
    Stacktype temp;
    init(&temp, MAX_STACK_SIZE);

    int index = 0;

    int len = strlen(infix);
    for (int i = 0; i < len; i++) {
        switch (infix[i]) {
        case '+':
        case '-':
        case '*':
        case '/':
            while (!is_empty(&temp) && prec(infix[i]) <= prec(peek(&temp))) {
                Exp[index++] = pop(&temp);
            }
            push(&temp, infix[i]);
            break;
        case '(':
            push(&temp, infix[i]);
            break;
        case ')':
            while (peek(&temp) != '(') {
                Exp[index++] = pop(&temp);
            }
            pop(&temp);
            break;
        default:
            Exp[index++] = infix[i];
            break;
        }

    }
    while (!is_empty(&temp)) {
        Exp[index++] = pop(&temp);
    }
    Exp[index] = '\0';
    return Exp;
}

int main() {
    char* expression = ScanExpression();
    char* Exp = infix_to_postfix(expression);
    printf("Postfix expression: %s\n", Exp);
    printf("%d", eval(Exp));
    return 0;
}
